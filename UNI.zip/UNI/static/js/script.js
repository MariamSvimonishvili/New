
const contactForm = document.getElementById('conntactForm');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault(); 

        
        const formData = {
            name: contactForm.querySelector('input[name="name"]').value,
            email: contactForm.querySelector('input[name="email"]').value,
            message: contactForm.querySelector('textarea[name="message"]').value
        };

        
        fetch('/contact', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert("მესიჯი წარმატებით გაიგზავნა და შეინახა!");
                contactForm.reset(); 
            } else {
                alert("შეცდომა მესიჯის გაგზავნისას.");
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("სერვერთან კავშირი ვერ დამყარდა.");
        });
    });
}