from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)

DATA_FILE = "messages.json"


def save_message(data):
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            messages = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        messages = []

    messages.append(data)

    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(messages, f, indent=4, ensure_ascii=False)


@app.route('/')
def home():
    return render_template('index.html') 


@app.route("/contact", methods=["POST"])
def contact():
    data = request.get_json()
    
    if not data:
        return jsonify({"success": False, "error": "მონაცემები არ არის"}), 400

    message = {
        "name": data.get("name"),
        "email": data.get("email"),
        "message": data.get("message"),
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    save_message(message)
    return jsonify({"success": True})

if __name__ == "__main__":
    app.run(debug=True)